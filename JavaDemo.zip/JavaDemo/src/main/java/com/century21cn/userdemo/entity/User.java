package com.century21cn.userdemo.entity;

public class User {

    private String name;

    private String sex;

    private Integer userid;

    /**
     * generate
     * code->generate
     * 快捷键:ALT+Insert
     * @return
     */

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }
}
